/*Step-by-step approach:

Create isValid() function to check if a cell at position (r, c) is inside the maze and unblocked.
Create findPath() to get all valid paths:
Base case: If the current position is the bottom-right cell, add the current path to the result and return.
Mark the current cell as blocked.
Iterate through all possible directions.
Calculate the next position based on the current direction.
If the next position is valid (i.e, if isValid() return true), append the direction to the current path and recursively call the findPath() function for the next cell.
Backtrack by removing the last direction from the current path.
Mark the current cell as unblocked before returning.*/

#include <bits/stdc++.h>
using namespace std;

string direction = "DLRU";
int dr[4] = {1, 0, 0, -1};
int dc[4] = {0, 1, -1, 0};

bool isValid(int r, int c, int n, vector<vector<int>> &maze)
{
    return r >= 0 && c >= 0 && r < n && c < n && maze[r][c] == 1;
}

void findPath(int r, int c, vector<vector<int>> &maze, int n, vector<string> &ans, string &currentPath)
{
    if (r == n - 1 && c == n - 1)
    {
        ans.push_back(currentPath);
        return;
    }

    maze[r][c] = 0;

    for (int i = 0; i < 4; i++)
    {
        int nextr = r + dr[i];
        int nextc = c + dc[i];
        if (isValid(nextr, nextc, n, maze))
        {
            currentPath += direction[i];
            cout << "Move " << direction[i] << " from (" << r << ", " << c << ") to (" << nextr << ", " << nextc << ")\n";
            findPath(nextr, nextc, maze, n, ans, currentPath);
            currentPath.pop_back();
            cout << "Backtrack from (" << nextr << ", " << nextc << ") to (" << r << ", " << c << ")\n";
        }
    }

    maze[r][c] = 1;
}

int main()
{
    int n = 4;

    vector<vector<int>> maze = {
        {1, 0, 0, 0},
        {1, 1, 0, 1},
        {1, 1, 0, 0},
        {0, 1, 1, 1}};

    vector<string> result;
    string currentPath = "";

    cout << "Steps:\n";
    findPath(0, 0, maze, n, result, currentPath);

    if (result.empty())
        cout << "No valid paths found.";
    else
    {
        cout << "Valid Paths:\n";
        for (int i = 0; i < result.size(); i++)
            cout << result[i] << " ";
    }
    cout << endl;

    return 0;
}
