#include <iostream>
#include <vector>
using namespace std;

const int V = 4; // Number of vertices in the graph

bool isSafe(int v, int pos, vector<int> &path, vector<vector<int>> &graph)
{
    if (graph[path[pos - 1]][v] == 0)
        return false;

    for (int i = 0; i < pos; i++)
        if (path[i] == v)
            return false;

    return true;
}

bool hamiltonianCycleUtil(vector<vector<int>> &graph, vector<int> &path, int pos)
{
    if (pos == V)
    {
        if (graph[path[pos - 1]][path[0]] == 1)
        {
            for (int v : path)
                cout << v << " ";
            cout << path[0] << endl;
            return true;
        }
        else
            return false;
    }

    for (int v = 1; v < V; v++)
    {
        if (isSafe(v, pos, path, graph))
        {
            path[pos] = v;
            cout << "Step: " << pos << " - Chose vertex " << v << endl;
            if (hamiltonianCycleUtil(graph, path, pos + 1))
                return true;
            path[pos] = -1; // Backtrack
            cout << "Step: " << pos << " - Backtrack from vertex " << v << endl;
        }
    }

    return false;
}

bool hamiltonianCycle(vector<vector<int>> &graph)
{
    vector<int> path(V, -1);
    path[0] = 0;

    if (!hamiltonianCycleUtil(graph, path, 1))
    {
        cout << "No Hamiltonian Cycle exists" << endl;
        return false;
    }

    return true;
}

int main()
{
    vector<vector<int>> graph = {
        {0, 1, 1, 1},
        {1, 0, 1, 0},
        {1, 1, 0, 1},
        {1, 0, 1, 0}};

    cout << "Hamiltonian Cycles:" << endl;
    hamiltonianCycle(graph);

    return 0;
}
