Q) Imagine you have a 20GB file with one string per line. Explain how you would sort the 
file.
Algorithm: (Pseudocode)
As we have limited memory we can divide the file into N chunks which are x megabytes 
each, 
where x is the amount of memory available in machine. 
Each chunk is sorted separately and then saved back to the file system. Once all the chunks 
are sorted, we then merge the chunks according to the following algorithm: 
1. Divide your memory into (N+1) parts. First N parts are used to read data from N 
chunks,
 the last one is used as a buffer. 
2. Load data to fill the first N data parts from N chunks respectively, perform an Nway merge sort to the buffer.
 3. While any data part is not empty, perform sort to the buffer. 
 4. If any data part is empty, load new content from the corresponding chunk.
 5. If the buffer is full, write buffer to the disk as output file, clear buffer. 
 6. Repeat step 4-5 until all N chunks and buffer are empty
Time Complexity: O(N*MlogM) N = total number of chunks, M = total numbers in each 
chunk
