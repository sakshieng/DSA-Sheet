#include <iostream>
using namespace std;

void TowerOfHanoi(int n, char start, char middle, char dest)
{
    if (n > 0)
    {
        TowerOfHanoi(n - 1, start, dest, middle);
        cout << "Move disk " << n << " from " << start << " to" << dest << endl;
        TowerOfHanoi(n - 1, start, dest, middle);
    }
}

int main()
{
    int N = 3;

    TowerOfHanoi(N, 'A', 'C', 'B');
    return 0;
}
