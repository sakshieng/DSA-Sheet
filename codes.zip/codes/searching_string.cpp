// Q) Given a sorted array of string which is interspersed with empty string, write a method to 
// find the location of a given string.
// EXAMPLE
// Input: find “ball” in {“at”, “”, “”, “ball”, “”, “”, “car”, “”, “”, “dad”, “”,””}
// Output: 4
// Algorithm: (Pseudocode) 
//  use modified binary search as follows 
//  if middle string is equal to given string 
//  return mid index 
//  traverse to left and right until we found non empty string in both direction 
//  if current string is less than given 
//  update search in second half 
//  else 
//  search in first half
// Source Code
#include <bits/stdc++.h>
using namespace std;
int findString(vector<string> str, string key, int left, int right)
{
    int low = 0;
    int high = str.size() - 1;
    while (low <= high)
    {
        int mid = (low + high) / 2;
        int left = mid;
        int right = mid;
        if (str[mid] == key)
            return mid;
        while (left >= low and str[left] == "")
        {
            left--;
        }
        while (right <= high and str[right] == "")
        {
            right++;
        }
        if (left >= low and str[left] == key)
            return left;
        if (right <= high and str[right] == key)
            return right;
        if (left >= low and str[left] < key)
            low = right + 1;
        if (right <= high and str[right] > key)
            high = left - 1;
    }
}
int main()
{
    vector<string> str{"at", "", "", "ball", "", "", "car", "", "", "dad", "", ""};
    string key = "ball";
    cout << "Given string present at index " << findString(str, key, 0, str.size() - 1) << endl;
    return 0;
}
// The complexity of the proposed algorithm(Time &Space)
//     Time : Worst case:
// O(n)
// Best Case : O(logn)
//                 Space : O(1) no extra space is used