#include <iostream>
#include <algorithm>

using namespace std;

class item
{
public:
    int p, w;

    item(int p, int w)
    {
        this->p = p;
        this->w = w;
    }
};

double frknapsack(int W, item arr[], int N)
{
    sort(arr, arr + N, [](item a, item b)
         {
        double r1 = (double)a.p / a.w;
        double r2 = (double)b.p / b.w;
        return r1 > r2; });
    double P = 0.0;

    cout << "Step 1: Items sorted by profit-to-weight ratio:" << endl;
    for (int i = 0; i < N; i++)
    {
        cout << "Item " << i + 1 << " (Profit: " << arr[i].p << ", Weight: " << arr[i].w << ", Profit/Weight Ratio: " << (double)arr[i].p / arr[i].w << ")" << endl;
    }

    for (int i = 0; i < N; i++)
    {
        cout << "Step 2: Current knapsack capacity: " << W << endl;
        if (arr[i].w <= W)
        {
            W -= arr[i].w;
            P += arr[i].p;
            cout << "   Added Item " << i + 1 << " to the knapsack." << endl;
            cout << "   Updated Profit: " << P << endl;
            cout << "   Updated Knapsack capacity: " << W << endl;
        }
        else
        {
            double fraction = (double)W / arr[i].w;
            P = P + (arr[i].p * fraction);
            cout << "   Added a fraction of Item " << i + 1 << " (Fraction: " << fraction << ") to the knapsack." << endl;
            cout << "   Updated Profit: " << P << endl;
            break;
        }
    }
    return P;
}

int main()
{
    item arr[] = {{60, 10}, {100, 20}, {120, 30}};
    int M = 50;
    int N = 3;

    cout << "Fractional Knapsack Steps and Output:" << endl;
    cout << "Maximum Profit = " << frknapsack(M, arr, N);

    return 0;
}
