// Algorithm : def find_maximum(arr, left, right) :
// #Base case : If the array contains only one element, it is the maximum.
//                                                  if left
//                                                  == right : return arr[left]
// #If there are two elements left, return the maximum of the two.
//                                                             if right
//                                                             == left + 1 : return max(arr[left], arr[right]) mid = left + (right - left) // 2 # Calculate the middle index
// #Check if the middle element is greater than its neighbors.
//                                                                                                                           if arr[mid] >
//                                                                                                                       arr[mid - 1] and
//                                                                                                                   arr[mid] > arr[mid + 1] : return arr[mid]
// #If the middle element is not the maximum, decide whether to go left or
//                                                                                                                                             right.if arr[mid] > arr[mid + 1] :
// #Go left if the right side is decreasing
//     return find_maximum(arr, left, mid - 1) else :
// #Go right if the left side is decreasing
//     return find_maximum(arr, mid + 1, right)
//         def find_maximum_in_peak(arr) : return find_maximum(arr, 0, len(arr) - 1)
// #Example usage:
//                                             arr = [ 1, 3, 8, 12, 4, 2 ] max_element = find_maximum_in_peak(arr)
//                                                                                                                       print("The maximum element in the array is:", max_element)
//                                                                                                                           Source Code :
#include <iostream>
    using namespace std;
int findmax(int arr[], int start, int end)
{
    if (start == end)
    {
        return arr[end];
    }
    int mid = start + (end - start) / 2;
    if (arr[mid] > arr[mid + 1] && arr[mid] > arr[mid - 1])
    {
        return arr[mid];
    }
    else if (arr[mid] < arr[mid - 1])
    {
        return findmax(arr, start, mid - 1);
    }
    else
    {
        return findmax(arr, mid + 1, end);
    }
}
int main()
{
    int n = 7;
    int arr[n] = {1, 2, 6, 9, 15, 8, 3};
    cout << "Array: ";
    for (int i : arr)
    {
        cout << i << " ";
    }
    cout << endl;
    cout << "Maximum element: " << findmax(arr, 0, n - 1);
    return 0;
}