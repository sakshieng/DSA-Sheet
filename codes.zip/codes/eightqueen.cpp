#include <iostream>
#include <vector>

using namespace std;

const int N = 8; // Board size

// Function to print the board in 0-1 matrix format
void printSolution(const vector<int> &board)
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (board[i] == j)
                cout << "1 ";
            else
                cout << "0 ";
        }
        cout << "\n";
    }
    cout << "\n";
}

// Function to check if a queen can be placed in the current row and column
bool isSafe(const vector<int> &board, int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        if (board[i] == col || abs(board[i] - col) == abs(i - row))
        {
            return false;
        }
    }
    return true;
}

// Recursive function to solve the 8-Queens problem and print steps
void solve8Queens(vector<int> &board, int row)
{
    if (row == N)
    {
        printSolution(board);
        return;
    }

    for (int col = 0; col < N; col++)
    {
        if (isSafe(board, row, col))
        {
            board[row] = col;
            solve8Queens(board, row + 1);
            board[row] = -1; // Backtrack
        }
    }
}

int main()
{
    vector<int> board(N, -1); // Initialize board with -1
    solve8Queens(board, 0);

    return 0;
}
