// Q 4 ) Let A and B tow arrays of n elements, each. Given a number K, 
// give an O (nlogn)
// time algorithmfor determining whether there exists a ϵ
//         A and b ϵ B such that a +
//     b = K.Algorithm : 1. Sort array B.2. For each element 'a' in array A,
//     perform a binary search in array B to find an element 'b' such that a + b = K.Source code :
#include <iostream>
#include <algorithm>
    using namespace std;
bool binarySearch(int arr[], int n, int target)
{
    int left = 0, right = n - 1;
    while (left <= right)
    {
        int mid = left + (right - left) / 2;
        if (arr[mid] == target)
            return true;
        else if (arr[mid] < target)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return false;
}
bool hasPairWithSum(int arrA[], int arrB[], int n, int K)
{
    sort(arrB, arrB + n); // Sort array B
    for (int i = 0; i < n; i++)
    {
        int complement = K - arrA[i];
        if (binarySearch(arrB, n, complement))
            return true;
    }
    return false;
}
int main()
{
    int n, K;
    cout << "Enter the value of n: ";
    cin >> n;
    int arrA[n], arrB[n];
    cout << "Enter elements of array A: ";
    for (int i = 0; i < n; i++)
        cin >> arrA[i];
    cout << "Enter elements of array B: ";
    for (int i = 0; i < n; i++)
        cin >> arrB[i];
    cout << "Enter the value of K: ";
    cin >> K;
    if (hasPairWithSum(arrA, arrB, n, K))
        cout << "There exists a pair (a, b) such that a + b = K." << endl;
    else
        cout << "No such pair exists." << endl;
    return 0;
}
