// Q 1 .Given an array A[0…n - 1] of n numbers containing repetition of
//         some number.Give an algorithmfor checking whether there are repeated
//             element or
//     not .Assume that we are not allowed to use additional space(i.e., we can use a few temporary variable, O(1) storage).Algorithm : Sort the given array using merge sort Check if element is repeated by comparing current element and its previous element
//                                                                                                                                                                                                                                              If current element equal to previous element return true;
// else return false;
// Source Code :
#include <iostream>
    using namespace std;
void merge(int arr[], int p, int q, int r)
{

    int n1 = q - p + 1;
    int n2 = r - q;
    int L[n1], M[n2];
    for (int i = 0; i < n1; i++)
        L[i] = arr[p + i];
    for (int j = 0; j < n2; j++)
        M[j] = arr[q + 1 + j];
    int i, j, k;
    i = 0;
    j = 0;
    k = p;
    while (i < n1 && j < n2)
    {
        if (L[i] <= M[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = M[j];
            j++;
        }
        k++;
    }
    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2)
    {
        arr[k] = M[j];
        j++;
        k++;
    }
}
void mergeSort(int arr[], int l, int r)
{
    if (l < r)
    {
        int m = l + (r - l) / 2;
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);
        merge(arr, l, m, r);
    }
}
bool isrepeated(int arr[], int n)
{
    for (int i = 1; i < n; i++)
    {
        if (arr[i - 1] == arr[i])
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
int main()
{
    int arr[] = {6, 5, 12, 5, 9, 12};
    int size = sizeof(arr) / sizeof(arr[0]);
    mergeSort(arr, 0, size - 1);
    if (isrepeated(arr, 6))
    {
        cout << "Duplicate Element Present" << endl;
    }
    else
    {
        cout << "No Duplicate Element Present" << endl;
    }
    return 0;
}
// Output – Time complexity : For merge sort : O(n log n)
//                                                 For checking duplication : O(n)