
/*Algorithm :
• If the original matrices are of size n1 x n2 and m1 x m2, create a
resultant matrix of size n1 x m2.
• Three nested loops will be used for the multiplication of the matrices.
• The first two loops are used to iterate over the rows and columns of
the result matrix, respectively.
• The innermost loop performs the multiplication of corresponding
elements from the current row of the first matrix and the current
column of the second matrix.
• Add these products to get the element of the result matrix.
• Repeat these steps for all elements of the result matrix.
Source code :
#include <iostream>
using namespace std;
int main()
{
 int a[10][10], b[10][10], mul[10][10], r, c, i, j, k;
 cout << "enter the number of row=";
 cin >> r;
 cout << "enter the number of column=";
 cin >> c;
 cout << "enter the first matrix element=\n";
 for (i = 0; i < r; i++)
 {
 for (j = 0; j < c; j++)
 {
 cin >> a[i][j];
 }
 }
 cout << "enter the second matrix element=\n";
 for (i = 0; i < r; i++)
 {
 for (j = 0; j < c; j++)
 {
 cin >> b[i][j];
 }
 }
 cout << "multiply of the matrix=\n";
 for (i = 0; i < r; i++)
 {
 for (j = 0; j < c; j++)
 {
 mul[i][j] = 0;
 for (k = 0; k < c; k++)
 {
 mul[i][j] += a[i][k] * b[k][j];
 }
 }
 }
 // for printing result
 for (i = 0; i < r; i++)
 {
 for (j = 0; j < c; j++)
 {
 cout << mul[i][j] << " ";
 }
 cout << "\n";
 }
 return 0;
}*/
#include <algorithm>
#include <iostream>
using namespace std;

struct Job {
    char id;
    int dead;
    int profit;
};

bool comparison(Job a, Job b) {
    return (a.profit > b.profit);
}

void printJobScheduling(Job arr[], int n) {
    // Step 1: Sort the jobs in descending order of profit
    sort(arr, arr + n, comparison);

    int result[n];
    bool slot[n];

    // Step 2: Initialize all slots as empty
    for (int i = 0; i < n; i++)
        slot[i] = false;

    // Step 3: Iterate through the sorted jobs and assign them to slots
    for (int i = 0; i < n; i++) {
        for (int j = min(n, arr[i].dead) - 1; j >= 0; j--) {
            if (slot[j] == false) {
                // Step 4: Assign the job to the available slot
                result[j] = i;
                slot[j] = true;
                break;
            }
        }
    }

    // Step 5: Print the sequence of jobs that maximizes profit
    cout << "Step 1: Jobs sorted by profit:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "Job " << arr[i].id << " (Profit: " << arr[i].profit << ")" << endl;
    }

    cout << "Step 2: Slot availability (initialized to empty):" << endl;
    for (int i = 0; i < n; i++) {
        cout << "Slot " << i << ": " << (slot[i] ? "Occupied" : "Empty") << endl;
    }

    cout << "Step 3: Assign jobs to slots:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "Trying to assign Job " << arr[i].id << " to a slot..." << endl;
        for (int j = min(n, arr[i].dead) - 1; j >= 0; j--) {
            if (slot[j] == false) {
                result[j] = i;
                slot[j] = true;
                cout << "   Assigned Job " << arr[i].id << " to Slot " << j << endl;
                break;
            }
        }
    }

    cout << "Step 4: Slot occupation after job assignment:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "Slot " << i << ": " << (slot[i] ? "Occupied" : "Empty") << endl;
    }

    cout << "Step 5: Sequence of jobs that maximizes profit: ";
    for (int i = 0; i < n; i++) {
        if (slot[i])
            cout << arr[result[i]].id << " ";
    }
    cout << endl;
}

int main() {
    Job arr[] = {
        { 'a', 2, 100 },
        { 'b', 1, 19 },
        { 'c', 2, 27 },
        { 'd', 1, 25 },
        { 'e', 3, 15 }
    };

    int n = sizeof(arr) / sizeof(arr[0]);

    cout << "Job Scheduling Steps and Output:" << endl;

    printJobScheduling(arr, n);

    return 0;
}
