// Algorithm: (Pseudocode)
// We can use radix sort to sort the given no.s in O(n) time.
// 1. In any number system (base n) n 2 has 3 digits, so we perform counting sort 3
// times, once for each of the digits.
// 2. Calculate digit as (number / place value) % base.
// 3. Get the frequency of each digit in the count array.
// 4. Decrement count[0] and then add the previous element to the current one for all
// elements to get the last index of the digit.
// 5. Traverse input array from backward (to maintain stability) in output array, at last
// index of the digit and then decrement the last index.
// 6. Copy the output to the original array.
// Source Code :
#include <bits/stdc++.h>
using namespace std;
void countSort(vector<int> &arr, int place)
{
    int n = arr.size();
    vector<int> count(n);
    for (int i = 0; i < n; i++)
        count[(arr[i] / place) % n]++;
    count[0]--;
    for (int i = 1; i < n; i++)
        count[i] += count[i - 1];
    for (int i = n - 1; i >= 0; i--)
        output[count[(arr[i] / place) % n]--] = arr[i];
    for (int i = 0; i < n; i++)
        arr[i] = output[i];
}
void radixSort(vector<int> &arr)
{
    int n = arr.size();
    for (int i = 0, place = 1; i < 3; i++, place *= n)
        countSort(arr, place);
}
int main()
{
    vector<int> arr{1, 3, 21, 19, 1, 100, 3, 49, 60, 5};
    radixSort(arr);
    for (int i = 0; i < arr.size(); i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
// The complexity of the proposed algorithm(Time &Space)
//     Time : O(n)
//                Space : O(n)
