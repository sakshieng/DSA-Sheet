#include <iostream>
#include <vector>
#include <queue>
using namespace std;
class Graph
{
private:
    int V;                   // Number of vertices
    vector<vector<int>> adj; // Adjacency list
public:
    Graph(int vertices) : V(vertices)
    {
        adj.resize(V);
    }
    void addEdge(int u, int v)
    {
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    bool isBipartite(int src)
    {
        vector<int> color(V, -1); // Initialize colors: -1 for uncolored, 0 for colorA, 1 for color B
 color[src] = 0;
queue<int> q;
q.push(src);
while (!q.empty())
{
    int u = q.front();
    q.pop();
    for (int v : adj[u])
    {
        if (color[v] == -1)
        {
            color[v] = 1 - color[u];
            q.push(v);
        }
        else if (color[v] == color[u])
        {
            return false; // Graph is not bipartite
        }
    }
}
return true; // Graph is bipartite
    }
    int getVertices() const
    {
        return V;
    }
};
int main()
{
    Graph g(5);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 3);
    g.addEdge(2, 4);
    bool isBipartite = true;
    for (int i = 0; i < g.getVertices(); i++)
    {
        if (g.isBipartite(i) == false)
        {
            isBipartite = false;
            break;
        }
    }
    if (isBipartite)
    {
        cout << "The graph is Bipartite." << endl;
    }
    else
    {
        cout << "The graph is not Bipartite." << endl;
    }
    return 0;
}