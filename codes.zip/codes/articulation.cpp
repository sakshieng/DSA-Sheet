#include <iostream>
#include <vector>
using namespace std;
class Graph
{
private:
    int V;                   // Number of vertices
    vector<vector<int>> adj; // Adjacency list
    void DFS(int u, vector<int> &disc, vector<int> &low, vector<int> &parent, vector<bool> &articulation, int &time)
    {
        int children = 0;
        disc[u] = low[u] = time;
        time++;
        for (int v : adj[u])
        {
            if (disc[v] == -1)
            {
                children++;
                parent[v] = u;
                DFS(v, disc, low, parent, articulation, time);
                low[u] = min(low[u], low[v]);
                if (low[v] >= disc[u] && parent[u] != -1)
                {
                    articulation[u] = true;
                }
            }
            else if (v != parent[u])
            {
                low[u] = min(low[u], disc[v]);
            }
        }
        if (parent[u] == -1 && children > 1)
        {
            articulation[u] = true;
        }
    }

public:
    Graph(int vertices) : V(vertices)
    {
        adj.resize(V);
    }
    void addEdge(int u, int v)
    {
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    void findArticulationPoints()
    {
        vector<int> disc(V, -1);
        vector<int> low(V, -1);
        vector<int> parent(V, -1);
        vector<bool> articulation(V, false);
        int time = 0;
        for (int i = 0; i < V; i++)
        {
            if (disc[i] == -1)
            {
                DFS(i, disc, low, parent, articulation, time);
            }
        }
        cout << "Articulation Points: ";
        for (int i = 0; i < V; i++)
        {
            if (articulation[i])
            {
                cout << i << " ";
            }
        }
        cout << endl;
    }
};
int main()
{
    Graph g(7);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 3);
    g.addEdge(3, 4);
    g.addEdge(4, 5);
    g.addEdge(5, 6);
    cout << "Articulation Points in the graph:" << endl;
    g.findArticulationPoints();
    return 0;
}
