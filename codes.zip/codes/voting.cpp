// Algorithm : 1 sort the given array of votes 2 traverse the sorted array if adjacent elements are the
//     same save max and candidate else save max
//         reset the count and save the candidate 3 return candidate
//             Source Code : 
import java.util.Arrays;
public
class Question2
{
public
    static void main(String[] args)
    {
        int votes[] = {10, 12, 10, 23, 11, 14, 67, 34, 90, 23, 88, 23};
        Arrays.sort(votes);
        System.out.println(Arrays.toString(votes));
        int maxi = Integer.MIN_VALUE;
        int winner = 0;
        int cnt = 0;
        for (int i = 0; i < votes.length; i++)
        {
            if (i != 0)
            {
                if (votes[i] == votes[i - 1])
                {
                    cnt++;
                }
                else
                {
                    if (maxi < cnt)
                    {
                        maxi = cnt;
                        winner = votes[i - 1];
                        cnt = 1;
                    }
                }
            }
            else
                cnt = 1;
        }
        System.out.println("The winner is : " + winner);
    }
}
