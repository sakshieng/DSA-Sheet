#include <iostream>
#include <vector>
#include <map>
#include <stack>
using namespace std;
class Graph
{
private:
    int V;                           // Number of vertices
    map<string, vector<string>> adj; // Adjacency list
    map<string, bool> visited;
    stack<string> order;

public:
    Graph()
    {
        V = 0;
    }
    void addCommittee(const string &committee)
    {
        if (adj.find(committee) == adj.end())
        {
            adj[committee] = vector<string>();
            visited[committee] = false;
            V++;
        }
    }
    void addDependency(const string &committee, const string &dependency)
    {
        adj[committee].push_back(dependency);
    }
    void topologicalSortUtil(const string &committee)
    {
        visited[committee] = true;
        for (const string &dep : adj[committee])
        {
            if (!visited[dep])
            {
                topologicalSortUtil(dep);
            }
        }
        order.push(committee);
    }
    void topologicalSort()
    {
        for (const auto &item : adj)
        {
            const string &committee = item.first;
            if (!visited[committee])
            {
                topologicalSortUtil(committee);
            }
        }
        cout << "Linear Order Execution of Committees/Entities:" << endl;
        while (!order.empty())
        {
            cout << order.top() << " "<<endl;
            order.pop();
        }
        cout << endl;
    }
};
int main()
{
    Graph g;
    g.addCommittee("Review Board");
    g.addCommittee("Hospitality");
    g.addCommittee("Registration");
    g.addCommittee("Finance");
    g.addCommittee("Session");
    g.addCommittee("Approval from TEQIP coordinator");
    g.addCommittee("Food");
    g.addDependency("Review Board", "Registration");
    g.addDependency("Review Board", "Paper");
    g.addDependency("Review Board", "Poster");
    g.addDependency("Hospitality", "Finance");
    g.addDependency("Hospitality", "Food");
    g.addDependency("Finance", "Food");
    g.addDependency("Session", "Approval from TEQIP coordinator");
    g.addDependency("Approval from TEQIP coordinator", "Review Board");
 g.addDependency("Approval from TEQIP coordinator", "Approval from director");
 g.topologicalSort();
 return 0;
}